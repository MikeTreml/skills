---
name: compliance-checker
description: Check software, infrastructure, configuration, and documentation for compliance with SOC 2, GDPR, HIPAA, PCI-DSS, ISO 27001, or NIST controls. Use when Codex is asked to perform compliance assessment, security control review, evidence collection, gap analysis, remediation planning, audit readiness review, or regulatory validation for source code, IaC, cloud settings, data flows, access controls, logging, encryption, retention, privacy, or incident-response materials.
---

# Compliance Checker

## Workflow

1. Confirm scope from the request: frameworks, target files or systems, environment, and whether evidence should be collected. If frameworks or targets are missing, inspect likely security, infrastructure, config, and documentation paths before asking.
2. Load [references/control-map.md](references/control-map.md) when mapping findings to framework controls or when the request names specific standards.
3. Inventory evidence from code, infrastructure, configs, CI/CD, policies, runbooks, diagrams, and tests. Prefer direct file references, line numbers, command output, and config keys over broad claims.
4. Evaluate each applicable control as `pass`, `partial`, `fail`, `not_applicable`, or `needs_human_evidence`.
5. Report gaps with priority, impact, remediation, and evidence. Never claim legal certification or audit completion; phrase results as engineering assessment and audit-readiness support.

## Review Targets

Prioritize these surfaces:

- Data protection: encryption at rest and in transit, key management, secrets handling, token storage, backup protection.
- Identity and access: least privilege, MFA or SSO hooks, role separation, service accounts, approval flows, privileged actions.
- Logging and monitoring: audit trails, immutable or retained logs, alerting, incident detection, access log coverage.
- Privacy and data rights: PII/PHI/cardholder-data discovery, purpose limitation, consent, deletion/export flows, retention limits.
- Secure SDLC: change management, code review, CI checks, dependency scanning, vulnerability management, test evidence.
- Infrastructure: network boundaries, public exposure, firewall/security-group rules, container hardening, IaC drift risks.
- Documentation: policies, runbooks, data maps, vendor lists, risk register, incident response, business continuity.

## Evidence Rules

Use a finding only when it is backed by evidence or explicitly marked as missing evidence.

For each finding include:

- `control`: framework and control id when known.
- `status`: `pass`, `partial`, `fail`, `not_applicable`, or `needs_human_evidence`.
- `evidence`: file path, line, config key, command output, or document section.
- `gap`: concise description of what is missing or risky.
- `remediation`: concrete next action.
- `priority`: `critical`, `high`, `medium`, or `low`.

## Output

Default to Markdown unless the user asks for JSON.

Use this structure:

```markdown
# Compliance Assessment
## Scope
## Summary
## Framework Results
## Findings
## Missing Evidence
## Recommended Remediation Plan
## Assumptions and Limits
```

For JSON, use:

```json
{
  "frameworks": [
    {
      "name": "soc2",
      "complianceScore": 0,
      "controls": [
        {
          "id": "CC6.1",
          "name": "Logical access controls",
          "status": "partial",
          "findings": [],
          "evidence": []
        }
      ]
    }
  ],
  "gaps": [
    {
      "control": "CC6.1",
      "gap": "No MFA evidence found for privileged accounts.",
      "remediation": "Document and enforce MFA for privileged access.",
      "priority": "high"
    }
  ],
  "summary": {
    "overallScore": 0,
    "passedControls": 0,
    "failedControls": 0,
    "notApplicable": 0
  }
}
```

## Scoring

Use scoring only as an estimate:

- `pass`: 1.0
- `partial`: 0.5
- `fail`: 0
- `needs_human_evidence`: 0.25
- `not_applicable`: exclude from denominator

State that scores are preliminary and depend on auditor interpretation and organizational evidence outside the repository.
