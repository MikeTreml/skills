---
name: ai-skill-packager
description: Convert loose notes, scripts, existing skills, agents, or MissionControl specialization folders into clean AI-ready skill or agent packages. Use when asked to clean up AI skill/agent materials, preserve an existing version, create a v2/codex-ready copy, package notes and scripts for AI use, or align a skill with Codex-style SKILL.md plus resources.
---

# AI Skill Packager

## Overview

Package messy notes, scripts, examples, and existing skill/agent folders into a clean AI-ready version without replacing the original. Prefer a versioned copy when cleanup changes structure, trigger behavior, or shared artifacts.

## Workflow

### 1. Establish the target harness

Identify whether the output is for Codex skills, MissionControl specializations, babysitter processes, or another AI harness. Do not mix schemas unless the user explicitly wants a cross-harness bridge.

For Codex skills:
- Keep `SKILL.md` frontmatter to `name` and `description`.
- Put UI metadata in `agents/openai.yaml`.
- Use `scripts/`, `references/`, and `assets/` only when they directly support the skill.

For MissionControl-style examples:
- Preserve existing `allowed-tools`, `metadata`, `agent.md`, and workflow conventions in the versioned copy unless converting to Codex is the explicit goal.
- Keep process integration references only when the named process files exist.

### 2. Inventory source material

Read only relevant source files before editing:
- Main instruction file: `SKILL.md`, `agent.md`, workflow, or notes file.
- Scripts that will remain bundled.
- Reference notes that explain domain behavior or examples.
- Nearby examples that define the target convention.

Classify each item as:
- **Core instructions**: keep in `SKILL.md` or `agent.md`.
- **Detailed reference**: move to `references/`.
- **Deterministic automation**: keep in `scripts/` and test.
- **Template/output material**: keep in `assets/`.
- **Scratch/process history**: leave out of the packaged version.

### 3. Create a versioned copy

Do not overwrite the source when the user asks to clean up without replacing. Use `scripts/create_versioned_skill.py`:

```bash
python scripts/create_versioned_skill.py <source-folder> <destination-parent> --version v2
```

The script refuses to overwrite an existing destination. If the destination exists, choose a new version suffix and leave the source untouched.

### 4. Rewrite for AI use

Use imperative instructions. Make the skill tell the next AI agent exactly how to act:
- Start from caller intent and trigger conditions.
- Keep operational steps short and ordered.
- Prefer concrete examples over generic explanation.
- Move long tables, notes, examples, and API details into `references/`.
- Keep scripts deterministic and documented by their CLI help, not by long prose in `SKILL.md`.
- Remove TODO placeholders, stale comments, duplicate notes, and claims not supported by the source.

### 5. Validate and test

For Codex skills:
- Run `quick_validate.py <skill-folder>` from the system `skill-creator` skill.
- Regenerate or review `agents/openai.yaml` when the skill name, purpose, or default prompt changes.

For scripts:
- Run the specific script path with a safe sample or `--help`.
- Fix failures instead of documenting around them.

For references:
- Check that every referenced file exists and is linked from `SKILL.md`.

## References

- Read `references/packaging-checklist.md` before large cleanups or versioned conversions.
- Read `references/agent-skill-improvement-guide.md` when asked for best practices, review notes, testing methods, eval design, or improvement recommendations for skills and agents.
